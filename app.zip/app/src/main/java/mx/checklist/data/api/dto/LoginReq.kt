package mx.checklist.data.api.dto
data class LoginReq(val email: String, val password: String)
