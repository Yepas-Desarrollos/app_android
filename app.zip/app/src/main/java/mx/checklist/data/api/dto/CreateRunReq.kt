package mx.checklist.data.api.dto
data class CreateRunReq(
    val storeCode: String,
    val templateId: Long
)
