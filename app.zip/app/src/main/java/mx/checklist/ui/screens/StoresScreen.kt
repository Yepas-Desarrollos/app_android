package mx.checklist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import mx.checklist.ui.StoresVM

@Suppress("UNUSED_PARAMETER")
@Composable
fun StoresScreen(
    vm: StoresVM,
    onStoreSelected: (String) -> Unit
) {
    var code by remember { mutableStateOf("T002") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Tiendas", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Código de tienda (ej. T002)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { onStoreSelected(code) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Continuar")
        }
    }
}
