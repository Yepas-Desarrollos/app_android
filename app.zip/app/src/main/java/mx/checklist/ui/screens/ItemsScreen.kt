package mx.checklist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import mx.checklist.ui.ItemsVM

@Suppress("UNUSED_PARAMETER")
@Composable
fun ItemsScreen(
    runId: Long,
    storeCode: String,
    vm: ItemsVM,
    onSubmit: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Items de la corrida $runId ($storeCode)",
            style = MaterialTheme.typography.headlineSmall
        )

        // Aquí iría la lista real de items (cuando conectes el VM).
        // Por ahora, un botón para cerrar/enviar:
        Button(
            onClick = { onSubmit() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Enviar checklist")
        }
    }
}
