package mx.checklist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import mx.checklist.ui.TemplatesVM

@Suppress("UNUSED_PARAMETER")
@Composable
fun TemplatesScreen(
    storeCode: String,
    vm: TemplatesVM,
    onRunCreated: (Long, String) -> Unit
) {
    var runIdText by remember { mutableStateOf("0") } // puedes dejar 0 y el backend creará uno real

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Plantillas - tienda $storeCode", style = MaterialTheme.typography.headlineSmall)

        // Si luego conectas VM para listar templates, reemplaza este input.
        OutlinedTextField(
            value = runIdText,
            onValueChange = { runIdText = it },
            label = { Text("Run ID (opcional)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                val id = runIdText.toLongOrNull() ?: 0L
                onRunCreated(id, storeCode)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Crear corrida")
        }
    }
}
