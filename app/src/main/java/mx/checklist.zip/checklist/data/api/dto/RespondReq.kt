package mx.checklist.data.api.dto
data class RespondReq(
    val responseStatus: String? = null,
    val responseText: String? = null,
    val responseNumber: Double? = null
)
