package mx.checklist.data.api.dto
data class TemplateDto(
    val id: Long,
    val name: String,
    val version: Int
)
