package mx.checklist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import mx.checklist.data.Repo
import mx.checklist.data.TokenStore
import mx.checklist.data.api.ApiClient
import mx.checklist.ui.Routes
import mx.checklist.ui.screens.ItemsScreen
import mx.checklist.ui.screens.LoginScreen
import mx.checklist.ui.screens.StoresScreen
import mx.checklist.ui.screens.TemplatesScreen
import mx.checklist.ui.vm.AuthViewModel
import mx.checklist.ui.vm.RunsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wiring de capa de datos
        val tokenStore = TokenStore(this)
        val repo = Repo(ApiClient.api, tokenStore)
        lifecycleScope.launch { tokenStore.tokenFlow.collect { ApiClient.setToken(it) } }

        setContent {
            MaterialTheme {
                val nav = rememberNavController()

                // ViewModels unificados
                val authVM = viewModel<AuthViewModel>(factory = SimpleFactory { AuthViewModel(repo) })
                val runsVM = viewModel<RunsViewModel>(factory = SimpleFactory { RunsViewModel(repo) })

                NavHost(navController = nav, startDestination = Routes.Login) {

                    composable(Routes.Login) {
                        LoginScreen(authVM) {
                            nav.navigate(Routes.Stores) {
                                popUpTo(Routes.Login) { inclusive = true }
                            }
                        }
                    }

                    composable(Routes.Stores) {
                        StoresScreen(runsVM) { storeCode ->
                            nav.navigate(Routes.template(storeCode))
                        }
                    }

                    composable(
                        route = Routes.Templates,
                        arguments = listOf(navArgument("storeCode") { defaultValue = "" })
                    ) { back ->
                        val storeCode = back.arguments?.getString("storeCode") ?: ""
                        TemplatesScreen(storeCode, runsVM) { runId, sc ->
                            nav.navigate(Routes.items(runId, sc))
                        }
                    }

                    composable(
                        route = Routes.Items,
                        arguments = listOf(
                            navArgument("runId") { type = NavType.LongType },
                            navArgument("storeCode") { defaultValue = "" }
                        )
                    ) { back ->
                        val runId = back.arguments?.getLong("runId") ?: 0L
                        val storeCode = back.arguments?.getString("storeCode") ?: ""
                        ItemsScreen(runId, storeCode, runsVM) {
                            nav.popBackStack(Routes.Stores, false)
                        }
                    }
                }
            }
        }
    }
}

// Factory simple para VMs con constructor custom
class SimpleFactory<T : ViewModel>(private val creator: () -> T) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T1 : ViewModel> create(modelClass: Class<T1>): T1 {
        val instance = creator()
        if (modelClass.isAssignableFrom(instance::class.java)) {
            return instance as T1
        }
        throw IllegalArgumentException("Unknown model class ${modelClass.name}")
    }
}
