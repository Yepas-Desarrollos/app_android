package mx.checklist.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import mx.checklist.data.Repo
import mx.checklist.data.api.dto.CreateRunReq
import mx.checklist.data.api.dto.RespondReq
import mx.checklist.data.api.dto.RunDto
import mx.checklist.data.api.dto.RunItemDto
import mx.checklist.data.api.dto.StoreDto
import mx.checklist.data.api.dto.TemplateDto

/**
 * ViewModel unificado para:
 * - Cargar tiendas
 * - Cargar plantillas por tienda
 * - Crear un run
 * - Cargar items del run
 * - Responder item
 * - Enviar/submit run
 */
class RunsViewModel(
    private val repo: Repo
) : ViewModel() {

    // Estado general
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Tiendas
    private val _stores = MutableStateFlow<List<StoreDto>>(emptyList())
    val stores: StateFlow<List<StoreDto>> = _stores

    // Plantillas
    private val _templates = MutableStateFlow<List<TemplateDto>>(emptyList())
    val templates: StateFlow<List<TemplateDto>> = _templates

    // Run actual
    private val _currentRunId = MutableStateFlow<Long?>(null)
    val currentRunId: StateFlow<Long?> = _currentRunId

    // Items del run
    private val _items = MutableStateFlow<List<RunItemDto>>(emptyList())
    val items: StateFlow<List<RunItemDto>> = _items

    /** ------------ Operaciones ------------- **/

    fun loadStores() {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                _stores.value = repo.getStores()
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al cargar tiendas"
            } finally {
                _loading.value = false
            }
        }
    }

    fun loadTemplates(storeCode: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                _templates.value = repo.getTemplates(storeCode)
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al cargar plantillas"
            } finally {
                _loading.value = false
            }
        }
    }

    /**
     * Crea un run para una tienda y plantilla.
     * Al terminar, actualiza currentRunId y ejecuta onDone con el id.
     */
    fun createRun(
        storeCode: String,
        templateId: Long,
        onDone: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                val created: RunDto = repo.createRun(CreateRunReq(storeCode = storeCode, templateId = templateId))
                _currentRunId.value = created.id
                onDone(created.id)
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al crear run"
            } finally {
                _loading.value = false
            }
        }
    }

    fun loadItems(runId: Long) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                _items.value = repo.getRunItems(runId)
                _currentRunId.value = runId
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al cargar items"
            } finally {
                _loading.value = false
            }
        }
    }

    /**
     * Responde un item del run.
     * Usa los campos flexibles del backend: responseStatus, responseText, responseNumber, scannedBarcode.
     */
    fun respond(
        itemId: Long,
        responseStatus: String,
        responseText: String? = null,
        responseNumber: Double? = null,
        scannedBarcode: String? = null,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repo.respond(
                    itemId = itemId,
                    req = RespondReq(
                        responseStatus = responseStatus,
                        responseText = responseText,
                        responseNumber = responseNumber,
                        scannedBarcode = scannedBarcode
                    )
                )
                onDone()
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al responder item"
            } finally {
                _loading.value = false
            }
        }
    }

    /**
     * Envía/submit el run y, si todo va bien, limpia items locales.
     */
    fun submit(runId: Long, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repo.submit(runId)
                _items.value = emptyList()
                onDone()
            } catch (t: Throwable) {
                _error.value = t.message ?: "Error al enviar run"
            } finally {
                _loading.value = false
            }
        }
    }
}
