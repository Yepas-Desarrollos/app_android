package mx.checklist.ui.screens
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import mx.checklist.ui.StoresVM

@Composable
fun StoresScreen(vm: StoresVM, goTemplates:(String)->Unit){
    val items by vm.items.collectAsState()
    LaunchedEffect(Unit){ vm.load() }
    LazyColumn(Modifier.fillMaxSize()){
        items(items){ s ->
            ListItem(headlineContent={ Text("${s.code} - ${s.name}") },
                modifier = Modifier.clickable { goTemplates(s.code) })
            Divider()
        }
    }
}
