package mx.checklist.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import mx.checklist.ui.LoginVM

@Composable
fun LoginScreen(vm: LoginVM, goStores:()->Unit){
    var email by remember { mutableStateOf("admin@yepas.local") }
    var pass by remember { mutableStateOf("Demo123*") }
    val st by vm.st.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
        Text("Iniciar sesión", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=email, onValueChange={email=it}, label={Text("Email")})
        OutlinedTextField(value=pass, onValueChange={pass=it}, label={Text("Contraseña")}, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(12.dp))
        Button(onClick={ vm.login(email, pass, goStores) }, enabled=!st.loading){ Text("Entrar") }
        st.error?.let { Text(it, color= Color.Red) }
    }
}
