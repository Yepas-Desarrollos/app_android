package mx.checklist.ui.screens
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import mx.checklist.ui.TemplatesVM

@Composable
fun TemplatesScreen(storeCode:String, vm: TemplatesVM, goItems:(Long,String)->Unit){
    val items by vm.items.collectAsState()
    LaunchedEffect(Unit){ vm.load() }
    LazyColumn {
        items(items){ t ->
            ListItem(
                headlineContent={ Text("${t.name} (${t.frequency})") },
                supportingContent={ Text(t.scope) },
                trailingContent = {
                    Button(onClick = {
                        CoroutineScope(Dispatchers.Main).launch {
                            val run = vm.createRun(storeCode, t.id)
                            goItems(run.id, storeCode)
                        }
                    }){ Text("Crear") }
                }
            )
            Divider()
        }
    }
}
