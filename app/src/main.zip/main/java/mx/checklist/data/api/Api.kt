package mx.checklist.data.api
import retrofit2.http.*

interface `Api` {
    @POST("auth/login") suspend fun login(@Body body: LoginReq): TokenRes
    @GET("stores") suspend fun stores(@Header("Authorization") b: String): List<StoreDto>
    @GET("templates") suspend fun templates(@Header("Authorization") b: String): List<TemplateDto>
    @POST("runs") suspend fun createRun(@Header("Authorization") b: String, @Body req: CreateRunReq): RunDto
    @GET("runs/{id}/items") suspend fun runItems(@Header("Authorization") b: String, @Path("id") id: Long): List<ItemDto>
    @POST("items/{id}/respond") suspend fun respond(@Header("Authorization") b: String, @Path("id") id: Long, @Body body: RespondReq): ItemDto
    @PATCH("runs/{id}/submit") suspend fun submitRun(@Header("Authorization") b: String, @Path("id") id: Long): RunDto
}


