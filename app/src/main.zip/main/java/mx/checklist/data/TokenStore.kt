package mx.checklist.data
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("chk_prefs")
class TokenStore(private val ctx: Context) {
  companion object { val KEY = stringPreferencesKey("token") }
  val tokenFlow: Flow<String?> = ctx.ds.data.map { it[KEY] }
  suspend fun save(t: String) { ctx.ds.edit { it[KEY] = t } }
  suspend fun clear() { ctx.ds.edit { it.remove(KEY) } }
}

