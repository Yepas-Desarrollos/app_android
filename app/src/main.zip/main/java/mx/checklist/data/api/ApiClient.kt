package mx.checklist.data.api
import com.squareup.moshi.Moshi
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import mx.checklist.BuildConfig
import retrofit2.http.Body
import retrofit2.http.POST
object ApiClient {
    @Volatile private var tokenMem: String? = null
    fun setToken(t: String?) { tokenMem = t }

    private val authInt = Interceptor { chain ->
        val req = chain.request()
        val t = tokenMem
        val newReq = if (t.isNullOrEmpty()) req else req.newBuilder().addHeader("Authorization", "Bearer $t").build()
        chain.proceed(newReq)
    }
    private val log = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
    private val ok = OkHttpClient.Builder().addInterceptor(authInt).addInterceptor(log).build()
    private val moshi = Moshi.Builder().build()

    val api: Api = Retrofit.Builder()
        .baseUrl(BuildConfig.BASE_URL)
        .client(ok)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(Api::class.java)
}

