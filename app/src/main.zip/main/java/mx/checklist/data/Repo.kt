package mx.checklist.data
import mx.checklist.data.api.*

class Repo(private val api: Api, private val tokens: TokenStore) {
    suspend fun login(email: String, pass: String): String {
        val t = api.login(LoginReq(email, pass)).access_token
        ApiClient.setToken(t); tokens.save(t); return t
    }
    suspend fun restoreToken(t: String?) = ApiClient.setToken(t)
    suspend fun stores() = api.stores("x")
    suspend fun templates() = api.templates("x")
    suspend fun createRun(storeCode: String, templateId: Long) = api.createRun("x", CreateRunReq(storeCode, templateId))
    suspend fun runItems(runId: Long) = api.runItems("x", runId)
    suspend fun respond(itemId: Long, body: RespondReq) = api.respond("x", itemId, body)
    suspend fun submitRun(runId: Long) = api.submitRun("x", runId)
}


