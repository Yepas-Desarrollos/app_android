package mx.checklist.data.api

import mx.checklist.data.api.dto.LoginReq
import mx.checklist.data.api.dto.LoginRes
import retrofit2.http.Body
import retrofit2.http.POST

interface ChecklistApi {
    @POST("auth/login")
    suspend fun login(@Body body: LoginReq): LoginRes
}
